<?php
	echo "<a href=\"home.php\" >Home</a> | ";
	echo "<a href=\"login.php\">Login</a>";
?>
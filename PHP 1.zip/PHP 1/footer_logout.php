<?php
	echo "<a href=\"home.php\" >Home</a> | ";
	echo "<a href=\"add.php\">Add New Animal</a> | ";
	echo "<a href=\"logout.php\">Logout</a>";
?>
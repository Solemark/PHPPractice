
<h2>Appointment Confirmed</h2>
<br>
<p> Hi {{ $name }}, please note your booking for {{ $date}} at {{ date('h:i a', strtotime($time . ':00')) }} with {{ $counsellor }} has been confirmed. </p>
<p>If you would like to view or change your appointment, please log into your account.</p>
<br>
<p>Kind Regards, </p>
<p>7Day Psychology</p>
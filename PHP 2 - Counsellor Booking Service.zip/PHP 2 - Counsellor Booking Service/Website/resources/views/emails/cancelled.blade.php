
<h2>Appointment Cancelled</h2>
<br>
<p> Hi {{ $name }}, please note your booking for {{ $date}} at {{ date('h:i a', strtotime($time . ':00')) }} with {{ $counsellor }} has been cancelled. </p>
<p>If you would like to make a new one, please log into your account. </p>
<br>
<p>Kind Regards, </p>
<p>7Day Psychology</p>
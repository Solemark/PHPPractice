App\Http\Controllers\Auth\VerificationController
===============






* Class name: VerificationController
* Namespace: App\Http\Controllers\Auth
* Parent class: [App\Http\Controllers\Controller](App-Http-Controllers-Controller.md)





Properties
----------


### $redirectTo

    protected string $redirectTo = \App\Providers\RouteServiceProvider::HOME

Where to redirect users after verification.



* Visibility: **protected**


Methods
-------


### __construct

    void App\Http\Controllers\Auth\VerificationController::__construct()

Create a new controller instance.



* Visibility: **public**




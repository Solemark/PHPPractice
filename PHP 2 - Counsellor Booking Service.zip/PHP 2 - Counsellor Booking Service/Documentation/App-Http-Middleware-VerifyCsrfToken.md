App\Http\Middleware\VerifyCsrfToken
===============






* Class name: VerifyCsrfToken
* Namespace: App\Http\Middleware
* Parent class: Illuminate\Foundation\Http\Middleware\VerifyCsrfToken





Properties
----------


### $except

    protected array $except = array()

The URIs that should be excluded from CSRF verification.



* Visibility: **protected**




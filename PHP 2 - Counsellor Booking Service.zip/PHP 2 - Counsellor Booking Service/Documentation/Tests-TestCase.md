Tests\TestCase
===============






* Class name: TestCase
* Namespace: Tests
* This is an **abstract** class
* Parent class: Illuminate\Foundation\Testing\TestCase







Methods
-------


### createApplication

    \Illuminate\Foundation\Application Tests\TestCase::createApplication()

Creates the application.



* Visibility: **public**




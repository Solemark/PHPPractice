App\Http\Controllers\Auth\ResetPasswordController
===============






* Class name: ResetPasswordController
* Namespace: App\Http\Controllers\Auth
* Parent class: [App\Http\Controllers\Controller](App-Http-Controllers-Controller.md)





Properties
----------


### $redirectTo

    protected string $redirectTo = \App\Providers\RouteServiceProvider::HOME

Where to redirect users after resetting their password.



* Visibility: **protected**




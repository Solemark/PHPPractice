Tests\Unit\UserControllerTest
===============






* Class name: UserControllerTest
* Namespace: Tests\Unit
* Parent class: [Tests\TestCase](Tests-TestCase.md)







Methods
-------


### testCreateClient

    mixed Tests\Unit\UserControllerTest::testCreateClient()





* Visibility: **public**




### testCreateCounsellor

    mixed Tests\Unit\UserControllerTest::testCreateCounsellor()





* Visibility: **public**




### testCreateAdmin

    mixed Tests\Unit\UserControllerTest::testCreateAdmin()





* Visibility: **public**




### testUpdateClientDetails

    mixed Tests\Unit\UserControllerTest::testUpdateClientDetails()





* Visibility: **public**




### testUpdateCounsellorDetails

    mixed Tests\Unit\UserControllerTest::testUpdateCounsellorDetails()





* Visibility: **public**




### testClientViewAllCounsellors

    mixed Tests\Unit\UserControllerTest::testClientViewAllCounsellors()





* Visibility: **public**




### testCounsellorViewAllCounsellors

    mixed Tests\Unit\UserControllerTest::testCounsellorViewAllCounsellors()





* Visibility: **public**




### testClientViewSearchedResults

    mixed Tests\Unit\UserControllerTest::testClientViewSearchedResults()





* Visibility: **public**




### testCounsellorViewSearchedResults

    mixed Tests\Unit\UserControllerTest::testCounsellorViewSearchedResults()





* Visibility: **public**




### client

    mixed Tests\Unit\UserControllerTest::client()





* Visibility: **private**




### counsellor

    mixed Tests\Unit\UserControllerTest::counsellor()





* Visibility: **private**




### admin

    mixed Tests\Unit\UserControllerTest::admin()





* Visibility: **private**




### clientData

    mixed Tests\Unit\UserControllerTest::clientData()





* Visibility: **private**




### counsellorData

    mixed Tests\Unit\UserControllerTest::counsellorData()





* Visibility: **private**




### createApplication

    \Illuminate\Foundation\Application Tests\TestCase::createApplication()

Creates the application.



* Visibility: **public**
* This method is defined by [Tests\TestCase](Tests-TestCase.md)




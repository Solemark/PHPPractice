App\Http\Controllers\Auth\ForgotPasswordController
===============






* Class name: ForgotPasswordController
* Namespace: App\Http\Controllers\Auth
* Parent class: [App\Http\Controllers\Controller](App-Http-Controllers-Controller.md)









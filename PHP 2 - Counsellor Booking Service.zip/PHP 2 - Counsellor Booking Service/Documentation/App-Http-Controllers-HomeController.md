App\Http\Controllers\HomeController
===============

Controller used to display the home page.




* Class name: HomeController
* Namespace: App\Http\Controllers
* Parent class: [App\Http\Controllers\Controller](App-Http-Controllers-Controller.md)







Methods
-------


### __construct

    void App\Http\Controllers\HomeController::__construct()

Create a new controller instance.



* Visibility: **public**




### index

    \Illuminate\Contracts\Support\Renderable App\Http\Controllers\HomeController::index()

Show the application dashboard.



* Visibility: **public**




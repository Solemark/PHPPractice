App\Http\Middleware\RedirectIfAuthenticated
===============






* Class name: RedirectIfAuthenticated
* Namespace: App\Http\Middleware







Methods
-------


### handle

    mixed App\Http\Middleware\RedirectIfAuthenticated::handle(\Illuminate\Http\Request $request, \Closure $next, string|null $guard)

Handle an incoming request.



* Visibility: **public**


#### Arguments
* $request **Illuminate\Http\Request**
* $next **Closure**
* $guard **string|null**



App\Http\Controllers\Controller
===============






* Class name: Controller
* Namespace: App\Http\Controllers
* Parent class: Illuminate\Routing\Controller









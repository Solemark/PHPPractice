App\Http\Middleware\EncryptCookies
===============






* Class name: EncryptCookies
* Namespace: App\Http\Middleware
* Parent class: Illuminate\Cookie\Middleware\EncryptCookies





Properties
----------


### $except

    protected array $except = array()

The names of the cookies that should not be encrypted.



* Visibility: **protected**




App\Providers\AuthServiceProvider
===============






* Class name: AuthServiceProvider
* Namespace: App\Providers
* Parent class: Illuminate\Foundation\Support\Providers\AuthServiceProvider





Properties
----------


### $policies

    protected array $policies = array()

The policy mappings for the application.



* Visibility: **protected**


Methods
-------


### boot

    void App\Providers\AuthServiceProvider::boot()

Register any authentication / authorization services.



* Visibility: **public**




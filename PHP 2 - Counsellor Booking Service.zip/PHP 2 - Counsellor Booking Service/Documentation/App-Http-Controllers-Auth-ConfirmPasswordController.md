App\Http\Controllers\Auth\ConfirmPasswordController
===============






* Class name: ConfirmPasswordController
* Namespace: App\Http\Controllers\Auth
* Parent class: [App\Http\Controllers\Controller](App-Http-Controllers-Controller.md)





Properties
----------


### $redirectTo

    protected string $redirectTo = \App\Providers\RouteServiceProvider::HOME

Where to redirect users when the intended url fails.



* Visibility: **protected**


Methods
-------


### __construct

    void App\Http\Controllers\Auth\ConfirmPasswordController::__construct()

Create a new controller instance.



* Visibility: **public**




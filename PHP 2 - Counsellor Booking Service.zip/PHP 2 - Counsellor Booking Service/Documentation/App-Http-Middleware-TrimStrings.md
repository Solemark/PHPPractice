App\Http\Middleware\TrimStrings
===============






* Class name: TrimStrings
* Namespace: App\Http\Middleware
* Parent class: Illuminate\Foundation\Http\Middleware\TrimStrings





Properties
----------


### $except

    protected array $except = array('password', 'password_confirmation')

The names of the attributes that should not be trimmed.



* Visibility: **protected**




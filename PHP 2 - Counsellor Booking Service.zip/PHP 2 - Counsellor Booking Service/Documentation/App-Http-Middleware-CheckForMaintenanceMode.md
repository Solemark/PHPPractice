App\Http\Middleware\CheckForMaintenanceMode
===============






* Class name: CheckForMaintenanceMode
* Namespace: App\Http\Middleware
* Parent class: Illuminate\Foundation\Http\Middleware\CheckForMaintenanceMode





Properties
----------


### $except

    protected array $except = array()

The URIs that should be reachable while maintenance mode is enabled.



* Visibility: **protected**



